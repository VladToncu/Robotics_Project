#! /usr/bin/env python


import rospy
import smach
from std_msgs.msg import String,Bool,Int8,Float32MultiArray
from sensor_msgs.msg import Image
import os
from geometry_msgs.msg import Pose,PoseWithCovarianceStamped
import numpy as np

from actionlib_msgs.msg import GoalID


import sys
sys.path.insert(0, '../')
import Notifications as Ns
import PeopleFrequencyAnalyser as PFA

loadedData = False
mapTile = PFA.TileMap(32, 32, 8, 8, loadedData)
foundPerson = PFA.PersonGridMap(mapTile, loadedData)

class LookForFaces(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Found','TooSmall'])
        self.result_sub = rospy.Subscriber("face", Image, self.result_cb)
        self.pub = rospy.Publisher('faceResult', Image, queue_size=10)
        self.vizpub = rospy.Publisher('probabilities', Float32MultiArray, queue_size=10)
        self.navCommandPub=rospy.Publisher('/movement/command',Int8,queue_size=10)
        self.navGoal = rospy.Publisher("/movement/pose", Pose, queue_size=10)
        self.navStatus=rospy.Subscriber("/movement/status",Int8,self.status_cb)
        self.pose = rospy.Subscriber("/amcl_pose", PoseWithCovarianceStamped, self.pose_cb )

        self.readyForMove=True
        self.readyForRotate=False
        self.executed = False
        self.tooSmall=False
        self.goals=[]

        # This is the part that does the people frequency analyser

        # Bottom right
        goal4 = Pose()
        goal4.position.x = 2.86988
        goal4.position.y = -12.19493
        goal4.orientation.z = 0.98234
        goal4.orientation.w = 0.18710
        self.goals.append(goal4)
        self.pos = 0
        self.status = -1

        goal=Pose()
        #Top left
        goal.position.x=-2.23557
        goal.position.y=13.01842
        goal.orientation.z=-0.99965
        goal.orientation.w=0.02637
        self.goals.append(goal)
        #test

        #Top right
        goal2 = Pose()
        goal2.position.x = 11.19837
        goal2.position.y = 7.48798
        goal2.orientation.z = -0.22574
        goal2.orientation.w = 0.97419
        self.goals.append(goal2)

        #Bottom left
        goal3 = Pose()
        goal3.position.x = -10.48478
        goal3.position.y = -7.55747
        goal3.orientation.z = -0.19031
        goal3.orientation.w = 0.98172
        self.goals.append(goal3)

        goal5 = Pose()
        self.goals.append(goal5)

        self.face=None
        self.location=None

    def convertToMapCoord(self, tileCoordX, tileCoordY):
        mapXOffset = 16
        mapYOffset = 16
        return tileCoordX - mapXOffset, tileCoordY - mapYOffset


    def pose_cb(self,msg):
        self.location=msg


    def execute(self, userdata):
        self.executed=False
        self.tooSmall = False


        rospy.sleep(0.5)

        while not rospy.is_shutdown():
            # check if it is interrupted
            if self.status == 4:
                # resume goal
                self.navCommandPub.publish(3)

            #check if face detection found something
            if self.executed:
                (x, y) = self.convertFromMapCoord(self.location.pose.pose.position.x, self.location.pose.pose.position.y)
                global foundPerson
                foundPerson.addPersonOnGrid(mapTile.localisePointOnTile(x, y))
                msg = Float32MultiArray()
                msg.data = np.array(foundPerson.probabilityGrid).flatten()
                self.vizpub.publish(msg)

                # This is where we add a person in the person grid, given that we found a person in that region
                (x, y) = self.convertFromMapCoord(self.location.pose.pose.position.x, self.location.pose.pose.position.y)
                print "Text: ", (x, y)
                self.currentPositionRobotTile = mapTile.localisePointOnTile(x, y)
                print self.currentPositionRobotTile  # Will need to take it from AMCL
                # foundPerson.addPersonOnGrid(self.currentPositionRobotTile)
                (tileX, tileY) = mapTile.mapPositionOfTile(self.currentPositionRobotTile)

                mapTile.putReachableLocation(tileX, tileY, (x, y))


                #if self.status==2 or self.status==3:
                #    print "Interrupted by a face, status = ", self.status
                #    # if moving or rotating interrupt
                #    self.navCommandPub.publish(2)

                if not self.face.height == 0:
                    print "sending face image for recognition"
                    self.pub.publish(self.face)
                else:
                    self.tooSmall = True
                self.face=None

                #Brutally interrupt anything and everything movement related
                print "interrupting"
                self.navCommandPub.publish(2)

                if self.tooSmall:
                    return 'TooSmall'
                else:
                    return 'Found'

            rospy.sleep(0.2)
            #send next goal


            if (self.status == 1 or self.status == 0 or self.status == -1 or self.status==5):
                if self.readyForMove:
                    self.readyForMove = False

                    #send move command
                    nextg = self.goals[self.pos]
                    # convert to tile, foundperson.nofoundpersonattile
                    self.navGoal.publish(nextg)
                    print "published new goal ", nextg

                    rospy.sleep(0.5)

                    self.pos+=1
                    if (self.pos > 3) and (foundPerson.stopGoingOnPattern() == False):
                        self.pos = 0
                        print "Still on patern"
                    elif (self.pos > 3) and (foundPerson.stopGoingOnPattern() == True):
                        print "Escaped"
                        self.pos = 4
                        self.maxPos = foundPerson.getMaximumProbability()
                        # self.pointToGo = self.maxTile.getMiddle()
                        # mapTile.getReachableLocation()
                        goal = Pose()
                        #(x, y) = self.convertToMapCoord(self.pointToGo[0], self.pointToGo[1])
                        (x, y) = self.convertToMapCoord(self.maxPos[0], self.maxPos[1])
                        goal.position.x = x
                        goal.position.y = y
                        goal.orientation.z = -0.99965
                        goal.orientation.w = 0.02637
                        self.goals[self.pos] = goal  # This one needs to be converted in pose
                if self.readyForRotate:
                    self.readyForRotate = False
                    self.navCommandPub.publish(1)


    def status_cb(self,msg):
        #print msg
        if msg.data==0:
            if not self.status==0:
                self.readyForRotate=True

            #finished moving
            self.status=0
        elif msg.data==1:
            if not self.status==1:
                # localize the goal we just reached on the tile and change the people frequency
                if (self.pos > 3):
                    print "changing stuff in the people freq analyzer(no person found at location)"
                    nextg = self.goals[self.pos]
                    (x, y) = self.convertFromMapCoord(nextg.position.x, nextg.position.y)
                    print mapTile.localisePointOnTile(x, y)
                    foundPerson.noPersonFoundAtLocation(mapTile.localisePointOnTile(x, y))

                self.readyForMove=True
            #finished rotating
            self.status=1
        elif msg.data==2:
            #rotating
            # self.readyForCommand=False
            self.status=2
        elif msg.data==3:
            #moving
            # self.readyForCommand=False
            self.status=3
        elif msg.data==4:
            #interrupted
            self.status=4
        elif msg.data==5:
            #skipping
            if not self.status==5:
                self.status=5
                self.readyForMove = True
                self.readyForRotate = False
                print "skipped goal"

    def result_cb(self, msg):
        if not self.executed:
            print "got face"
            self.face=msg
            self.executed=True

    def convertFromMapCoord(self, tileCoordX, tileCoordY):
        mapXOffset = 16
        mapYOffset = 16
        return tileCoordX + mapXOffset, tileCoordY + mapYOffset


class CallPerson(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Found', 'Timeout'])
        self.executed = False
        self.result_sub = rospy.Subscriber("face", Image, self.result_cb)
        self.pub = rospy.Publisher('faceResult', Image, queue_size=10)
        self.amcl_pose = rospy.Subscriber("/amcl_pose", PoseWithCovarianceStamped, self.pose_cb )
        self.face=None
        self.pose=None
        self.currentPositionRobotTile = mapTile.localisePointOnTile(0, 0)

    def execute(self, userdata):
        global mapTile
        global foundPerson
        print mapTile
        print "Enough people ", foundPerson.stopGoingOnPattern()
        self.executed=False
        self.face=None
        print "please come closer"
        os.system("espeak 'Please come closer for identification.'")


        #wait for robot to speak before starting the countdown
        rospy.sleep(3)

        startTime=rospy.get_time()
        while not rospy.is_shutdown():
            if self.executed:
                print "sending face for recognition"
                self.pub.publish(self.face)
                return 'Found'
            if rospy.get_time()-startTime>10:
                os.system("espeak 'Security will be notified.'")
                self.executed = True
                return 'Timeout'

    def convertFromMapCoord(self, tileCoordX, tileCoordY):
        mapXOffset = 16
        mapYOffset = 16
        return tileCoordX + mapXOffset, tileCoordY + mapYOffset

    def result_cb(self, msg):
        if not self.executed:
            if not msg.height == 0:
                print "found face size: ",msg.height," ",msg.width
                self.face=msg
                self.executed = True

    def pose_cb(self,msg):
        self.pose=msg

class FaceRecognition(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Yes','No'])
        self.result_sub = rospy.Subscriber("faceIdentified", Bool, self.result_cb)
        self.executed = False
        self.response = False

    def execute(self, userdata):

        self.executed = False
        while not rospy.is_shutdown():
            if self.executed:
                print "Response in execute function", self.response
                if self.response:
                    print 'verified'
                    os.system("espeak 'Thank you, have a nice day.'")
                    self.response = False
                    rospy.sleep(3)
                    return 'Yes'
                else:
                    os.system("espeak 'Unable to recognize face, please present card to the reader.'")
                    self.response = False
                    rospy.sleep(0.5)
                    return 'No'
            else:
                rospy.sleep(0.2)

    def result_cb(self, msg):
        print msg.data
        if msg.data:
            self.response=True
        else:
            self.response=False
        print "Response in call back", self.response
        self.executed = True


class CardReader(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Yes','No'])
        self.result_sub = rospy.Subscriber("nfcResult", Bool, self.result_cb)
        self.pub = rospy.Publisher('nfcControlTopic', String, queue_size=10)
        self.executed = False
        self.response=None

    def execute(self, userdata):
        self.executed=False
        self.response=None
        self.pub.publish("start")
        startTime = rospy.get_time()
        while not rospy.is_shutdown():
            if rospy.get_time() - startTime > 15:
                self.executed = True
                os.system("espeak 'Failed to present card, security will be notified.'")
                return 'No'

            if self.executed:
                self.pub.publish('stop')
                if self.response:
                    os.system("espeak 'Thank you, please wait to register face.'")
                    #rospy.sleep(3)

                    return 'Yes'
                else:
                    os.system("espeak 'Unrecognized card, security will be notified.'")
                    rospy.sleep(3)

                    return 'No'
            else:
                rospy.sleep(0.2)

    def result_cb(self, msg):
        if not self.executed:
            self.response=msg.data
            self.executed=True


class Notification(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Done','Fail'])
        self.executed = False
        self.sms = Ns.sms.sms()
        self.notification=None

    def execute(self, userdata):
        print "sending notifications"
        #self.sms.sendSMS("+40721565521")
        #self.notification=Ns.Notifications.Send_Notifications()
        if False:
            return 'Fail'
        rospy.sleep(5)
        return 'Done'

class SaveFace(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes = ['Done'])
        self.executed = False
        self.result_sub = rospy.Subscriber("face", Image, self.result_cb)
        self.pub = rospy.Publisher('saveFace', Image, queue_size=10)
        self.tooSmall=True
        self.face=None

    def execute(self, userdata):
        self.executed=False
        print "preparing to save face"
        self.face = None
        #wait for robot to speak before starting the countdown
        rospy.sleep(3)


        startTime=rospy.get_time()
        if self.tooSmall:
            os.system("espeak 'Please come closer.'")
        while not rospy.is_shutdown():
            if self.executed:
                print "saving face"
                os.system("espeak 'Face registered, thank you.'")
                self.pub.publish(self.face)
                rospy.sleep(2)
                return 'Done'
            if rospy.get_time()-startTime>10:
                self.executed=True
                os.system("espeak 'Failed to save face.'")
                return 'Done'

    def result_cb(self, msg):
        if not self.executed:
            if not msg.height == 0:
                self.face=msg
                #print "found face size: ",msg.height," ",msg.width
                self.executed = True
                self.tooSmall=False


            else:
                self.tooSmall=True


def main():
    rospy.init_node('state_machine')
    sm = smach.StateMachine(outcomes=['END'])
    with sm:
        #smach.StateMachine.add('Patrol', Patrol(), transitions={'Found': 'FaceRecognition', 'TooSmall': 'CallPerson'})
        smach.StateMachine.add('LookForFaces', LookForFaces(), transitions={'Found': 'FaceRecognition', 'TooSmall': 'CallPerson'})
        smach.StateMachine.add('CallPerson', CallPerson(), transitions={'Found': 'FaceRecognition', 'Timeout': 'Notification'})
        smach.StateMachine.add('FaceRecognition', FaceRecognition(), transitions={'Yes': 'LookForFaces', 'No': 'CardReader'})
        smach.StateMachine.add('CardReader', CardReader(), transitions={'Yes': 'SaveFace', 'No': 'Notification'})
        smach.StateMachine.add('SaveFace', SaveFace(), transitions={'Done': 'LookForFaces'})
        smach.StateMachine.add('Notification', Notification(), transitions={'Done': 'LookForFaces', 'Fail':'END'})

    outcome = sm.execute()
    rospy.spin()

if __name__ == '__main__':
    main()