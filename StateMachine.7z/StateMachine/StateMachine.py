#! /usr/bin/env python


import rospy
import smach
from std_msgs.msg import String,Bool,Int8
from sensor_msgs.msg import Image
import os
from geometry_msgs.msg import Pose

from actionlib_msgs.msg import GoalID


import sys
sys.path.insert(0, '../')
import Notifications as Ns





class LookForFaces(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Found','TooSmall'])
        self.result_sub = rospy.Subscriber("face", Image, self.result_cb)
        self.pub = rospy.Publisher('faceResult', Image, queue_size=10)
        self.navCommandPub=rospy.Publisher('/movement/command',Int8,queue_size=10)
        self.navGoal = rospy.Publisher("/movement/pose", Pose, queue_size=10)
        self.navStatus=rospy.Subscriber("/movement/status",Int8,self.status_cb)
        self.readyForCommand=True
        self.executed = False
        self.tooSmall=False
        self.goals=[]

        # Bottom right
        goal4 = Pose()
        goal4.position.x = 2.86988
        goal4.position.y = -12.19493
        goal4.orientation.z = 0.98234
        goal4.orientation.w = 0.18710
        self.goals.append(goal4)
        self.pos = 0
        self.status = -1

        goal=Pose()
        #Top left
        goal.position.x=-2.23557
        goal.position.y=13.01842
        goal.orientation.z=-0.99965
        goal.orientation.w=0.02637
        self.goals.append(goal)
        #test

        #Top right
        goal2 = Pose()
        goal2.position.x = 11.19837
        goal2.position.y = 7.48798
        goal2.orientation.z = -0.22574
        goal2.orientation.w = 0.97419
        self.goals.append(goal2)

        #Bottom left
        goal3 = Pose()
        goal3.position.x = -10.48478
        goal3.position.y = -7.55747
        goal3.orientation.z = -0.19031
        goal3.orientation.w = 0.98172
        self.goals.append(goal3)

        self.face=None


    def execute(self, userdata):
        self.executed=False
        self.tooSmall = False


        #check if it is interrupted
        if self.status==4:
            #resume goal
            self.navCommandPub.publish(3)
        else:
            #send next goal
            nextg = self.goals[self.pos]
            print nextg
            rospy.sleep(1)
            self.navGoal.publish(nextg)
            print "published first goal :P"
            self.pos += 1
            if self.pos >3:
                self.pos = 0
            self.readyForCommand = False
        while not rospy.is_shutdown():

            if self.executed:

                if self.status==2 or self.status==3:
                    print "Interrupted by a face, status = ", self.status
                    # if moving or rotating interrupt
                    self.navCommandPub.publish(2)

                if not self.face.height == 0:
                    print "sending face image for recognition"
                    self.pub.publish(self.face)
                else:
                    self.tooSmall = True

                self.face=None
                if self.tooSmall:
                    return 'TooSmall'
                else:
                    return 'Found'
            rospy.sleep(0.2)
            if self.status == 4:
                pass
                #resuming
                #do we need to resume here?
                #self.navCommandPub.publish(3)
            elif (self.status == 1 or self.status == 0) and self.readyForCommand:
                #send move command
                nextg = self.goals[self.pos]

                #TODO get next pose from Vlad's code

                self.navGoal.publish(nextg)
                print "published new goal ", nextg
                self.readyForCommand=False
                rospy.sleep(0.5)

                self.pos+=1
                if self.pos==4:
                    self.pos=0



    def status_cb(self,msg):
        #print "status callack ",msg
        if msg.data==0:
            if not self.status==0:
                self.readyForCommand=True
            #finished moving
            self.status=0
        elif msg.data==1:
            #finished rotating
            self.status=1
        elif msg.data==2:
            #rotating
            # self.readyForCommand=False
            self.status=2
        elif msg.data==3:
            #moving
            # self.readyForCommand=False
            self.status=3
        elif msg.data==4:
            #interrupted
            self.status=4


    def result_cb(self, msg):
        if not self.executed:
            print "got face"
            self.face=msg
            self.executed=True


class CallPerson(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Found', 'Timeout'])
        self.executed = False
        self.result_sub = rospy.Subscriber("face", Image, self.result_cb)
        self.pub = rospy.Publisher('faceResult', Image, queue_size=10)
        self.face=None

    def execute(self, userdata):
        self.executed=False
        self.face=None
        print "please come closer"
        os.system("espeak 'Please come closer for identification.'")
        #wait for robot to speak before starting the countdown
        rospy.sleep(3)

        startTime=rospy.get_time()
        while not rospy.is_shutdown():
            if self.executed:
                print "sending face for recognition"
                self.pub.publish(self.face)
                return 'Found'
            if rospy.get_time()-startTime>10:
                os.system("espeak 'Security will be notified.'")
                self.executed = True
                return 'Timeout'

    def result_cb(self, msg):
        if not self.executed:
            if not msg.height == 0:
                print "found face size: ",msg.height," ",msg.width
                self.face=msg
                self.executed = True



class FaceRecognition(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Yes','No'])
        self.result_sub = rospy.Subscriber("faceIdentified", Bool, self.result_cb)
        self.executed = False
        self.response = False

    def execute(self, userdata):

        self.executed = False
        while not rospy.is_shutdown():
            if self.executed:
                print "Response in execute function", self.response
                if self.response:
                    print 'verified'
                    os.system("espeak 'Thank you, have a nice day.'")
                    self.response = False
                    rospy.sleep(3)
                    return 'Yes'
                else:
                    os.system("espeak 'Unable to recognize face, please present card to the reader.'")
                    self.response = False
                    rospy.sleep(0.5)
                    return 'No'
            else:
                rospy.sleep(0.2)

    def result_cb(self, msg):
        print msg.data
        if msg.data:
            self.response=True
        else:
            self.response=False
        print "Response in call back", self.response
        self.executed = True


class CardReader(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Yes','No'])
        self.result_sub = rospy.Subscriber("nfcResult", Bool, self.result_cb)
        self.pub = rospy.Publisher('nfcControlTopic', String, queue_size=10)
        self.executed = False
        self.response=None

    def execute(self, userdata):
        self.executed=False
        self.response=None
        self.pub.publish("start")
        startTime = rospy.get_time()
        while not rospy.is_shutdown():
            if rospy.get_time() - startTime > 15:
                self.executed = True
                os.system("espeak 'Failed to present card, security will be notified.'")
                return 'No'

            if self.executed:
                self.pub.publish('stop')
                if self.response:
                    os.system("espeak 'Thank you, please wait to register face.'")
                    #rospy.sleep(3)

                    return 'Yes'
                else:
                    os.system("espeak 'Unrecognized card, security will be notified.'")
                    rospy.sleep(3)

                    return 'No'
            else:
                rospy.sleep(0.2)

    def result_cb(self, msg):
        if not self.executed:
            self.response=msg.data
            self.executed=True


class Notification(smach.State):

    def __init__(self):
        smach.State.__init__(self, outcomes = ['Done','Fail'])
        self.executed = False
        self.sms = Ns.sms.sms()
        self.notification=None

    def execute(self, userdata):
        print "sending notifications"
        #self.sms.sendSMS("+40721565521")
        #self.notification=Ns.Notifications.Send_Notifications()
        if False:
            return 'Fail'
        rospy.sleep(5)
        return 'Done'

class SaveFace(smach.State):
    def __init__(self):
        smach.State.__init__(self, outcomes = ['Done'])
        self.executed = False
        self.result_sub = rospy.Subscriber("face", Image, self.result_cb)
        self.pub = rospy.Publisher('saveFace', Image, queue_size=10)
        self.tooSmall=True
        self.face=None

    def execute(self, userdata):
        self.executed=False
        print "preparing to save face"
        self.face = None
        #wait for robot to speak before starting the countdown
        rospy.sleep(3)


        startTime=rospy.get_time()
        if self.tooSmall:
            os.system("espeak 'Please come closer.'")
        while not rospy.is_shutdown():
            if self.executed:
                print "saving face"
                os.system("espeak 'Face registered, thank you.'")
                self.pub.publish(self.face)
                rospy.sleep(2)
                return 'Done'
            if rospy.get_time()-startTime>10:
                self.executed=True
                os.system("espeak 'Failed to save face.'")
                return 'Done'

    def result_cb(self, msg):
        if not self.executed:
            if not msg.height == 0:
                self.face=msg
                #print "found face size: ",msg.height," ",msg.width
                self.executed = True
                self.tooSmall=False


            else:
                self.tooSmall=True


def main():
    rospy.init_node('state_machine')
    sm = smach.StateMachine(outcomes=['END'])
    with sm:
        #smach.StateMachine.add('Patrol', Patrol(), transitions={'Found': 'FaceRecognition', 'TooSmall': 'CallPerson'})
        smach.StateMachine.add('LookForFaces', LookForFaces(), transitions={'Found': 'FaceRecognition', 'TooSmall': 'CallPerson'})
        smach.StateMachine.add('CallPerson', CallPerson(), transitions={'Found': 'FaceRecognition', 'Timeout': 'Notification'})
        smach.StateMachine.add('FaceRecognition', FaceRecognition(), transitions={'Yes': 'LookForFaces', 'No': 'CardReader'})
        smach.StateMachine.add('CardReader', CardReader(), transitions={'Yes': 'SaveFace', 'No': 'Notification'})
        smach.StateMachine.add('SaveFace', SaveFace(), transitions={'Done': 'LookForFaces'})
        smach.StateMachine.add('Notification', Notification(), transitions={'Done': 'LookForFaces', 'Fail':'END'})

    outcome = sm.execute()
    rospy.spin()



if __name__ == '__main__':
    main()