#!/usr/bin/env python
import threading
import math
import time
from tf import transformations as tf

import rospy

from geometry_msgs.msg import Pose, PoseStamped, PoseWithCovarianceStamped, Twist, Quaternion
from std_msgs.msg import Int8
from actionlib_msgs.msg import GoalID, GoalStatusArray, GoalStatus
from std_srvs.srv import Empty

from threading import Thread

# Parameters
mapXOffset = 16
mapYOffset = 16
slowRotateSpeed = 0.5
slowRotateTime = 12  # In seconds
statusInterval = 1  # In seconds


class PausableTimer:
    def __init__(self, interval, callback):
        self.interval = interval
        self.callback = callback
        self.timer = threading.Timer(interval, callback)
        self.t0 = time.time()

    def start(self):
        self.timer.start()

    def cancel(self):
        self.timer.cancel()

    def pause(self):
        self.timer.cancel()
        self.t1 = time.time()

    def resume(self):
        self.interval = self.interval - self.t1 + self.t0
        self.t0 = time.time()
        self.timer = threading.Timer(self.interval, self.callback)
        self.timer.start()


class RotationThread(Thread):
    def __init__(self):
        Thread.__init__(self)

    def run(self):
        rate = rospy.Rate(10)  # 10hz
        print Movement.status

        while Movement.status == 3 and not rospy.is_shutdown():
            Movement.robot_cmd_vel_pub.publish(Movement.rotate_command)
            rate.sleep()


class Movement:
    timer = None
    goal = None

    status = -1
    # 0 - finished moving
    # 1 - finished rotating
    # 2 - moving
    # 3 - rotating
    # 4 - interrupted
    # 5 - skipped

    interruptedMoving = None
    finishedRotating = False
    rotationThread = None

    robot_cmd_vel_pub = None
    rotate_command = None

    def __init__(self):
        Movement.rotate_command = Twist()
        Movement.rotate_command.angular.z = slowRotateSpeed

        # Init publishers and subscribers
        self.command_sub = rospy.Subscriber("/movement/command", Int8, self.commandCallback)
        self.next_goal_sub = rospy.Subscriber("/movement/pose", Pose, self.moveToPosition)
        self.goal_status_sub = rospy.Subscriber("move_base/status", GoalStatusArray, self.statusCallback)

        self.result_pub = rospy.Publisher("/movement/status", Int8, queue_size=10)
        self.robot_goal_pub = rospy.Publisher("/move_base_simple/goal", PoseStamped, queue_size=10)
        self.robot_cmd_vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        Movement.robot_cmd_vel_pub = self.robot_cmd_vel_pub
        self.robot_cancel_pub = rospy.Publisher("/move_base/cancel", GoalID, queue_size=10)

        self.publishStatus()

    def statusCallback(self, data):
        # data = GoalStatusArray()
        # print("The goal status array has " + str(len(data.status_list)) + " elements")
        if len(data.status_list) > 0:
            status = data.status_list[len(data.status_list)-1]
            # status = GoalStatus()

            if self.status == 2:  # Moving
                if status.status == 3:  # If it is finished
                    self.status = 0
                    print("Finished moving")
                elif status.status == 4:  # If it got cancelled
                    self.status = 5
                    self.pauseMovement()
                    self.clearCostmap()
                    print "Goal was not reached. Skipping......."

    def publishStatus(self):
        self.result_pub.publish(self.status)
        threading.Timer(statusInterval, self.publishStatus).start()

    def commandCallback(self, data):
        print "Got command: " + str(data.data)
        if data.data == 1:
            self.rotateSlowly()
            return
        if data.data == 2:
            self.interrupt()
        if data.data == 3:
            self.resume()

    def moveToPosition(self, data):

        if self.goal == 2:
            print "Received movement command while already moving"
            return
        elif self.goal == 3:
            print "Received movement command while rotating"
            return

        # Save the goal in case there is an interrupt
        self.goal = data

        print("Got move command. Will rotate and then move\n")

        current_pose = rospy.wait_for_message("/amcl_pose", PoseWithCovarianceStamped)
        # current_pose = PoseWithCovarianceStamped()
        # data = Pose()

        # Calculate angle of the line between the current pose and the goal
        # deltaX = data.position.x - current_pose.pose.pose.position.x
        # deltaY = data.position.y - current_pose.pose.pose.position.y
        # angle = tf.quaternion_from_euler(0, 0, math.atan2(deltaY, deltaX))

        # # Send rotation
        # self.status = 3
        # robot_goal = PoseStamped()
        # robot_goal.pose.position = current_pose.pose.pose.position
        # robot_goal.pose.orientation = Quaternion(x=angle[0], y=angle[1], z=angle[2], w=angle[3])
        # robot_goal.header.frame_id = "map"
        # self.robot_goal_pub.publish(robot_goal)
        # self.finishedRotating = False
        #
        # #print "Finished rotating" + str(self.finishedRotating)
        # while not self.finishedRotating:
        #     rospy.sleep(0.2)
        #
        #
        # print("I finished rotating and will move")

        # Send actual goal
        robot_goal = PoseStamped(pose=data)
        robot_goal.header.frame_id = "map"

        self.robot_goal_pub.publish(robot_goal)
        self.status = 2

    def clearCostmap(self):
        rospy.wait_for_service('/move_base/clear_costmaps')
        try:
            clear = rospy.ServiceProxy('/move_base/clear_costmaps', Empty)
            resp=clear()
            return
        except rospy.ServiceException, e:
             print "Service call failed: %s" % e

    def rotateSlowly(self):
        if self.status == 3:
            print "I'm already rotating you idiot!"
            return
        waitTime = self.getRotateTime()
        self.timer = PausableTimer(waitTime, self.timerCallback)
        self.timer.start()

        self.publishRotation()

    def publishRotation(self):
        if self.status == 2:
            print "Received rotation command while moving"
            return
        elif self.status == 3:
            print "Received rotation command while already rotating"
            return

        print("Rotating")
        self.status = 3
        Movement.status = self.status

        self.rotationThread = RotationThread()
        self.rotationThread.start()

    def timerCallback(self):
        self.status = 1
        Movement.status = self.status
        print "Finished rotating"

    def interrupt(self):
        print "Interrupting"
        if self.status == 4:
            print "Received interrupt command while already stopped"
            return
        elif self.status == 2:  # moving
            self.interruptedMoving = True
            self.pauseMovement()

        elif self.status == 3:  # rotating
            self.pauseSlowRotation()
            self.interruptedMoving = False

        self.status = 4
        Movement.status = self.status
        print "Interrupted"

    def resume(self):
        if self.status != 4:
            print "Why you do this?"
            raise Exception("state machine, why you do this?")
        self.clearCostmap()
        if self.interruptedMoving:
            self.resumeMovement()
        else:
            self.resumeSlowRotation()

    def getRotateTime(self):
        return slowRotateTime

    def pauseSlowRotation(self):
        self.timer.pause()
        self.robot_cmd_vel_pub.publish(Twist())

    def resumeSlowRotation(self):
        self.timer.resume()
        self.publishRotation()

    def convertToMapCoord(self, tileCoordX, tileCoordY):
        return tileCoordX + mapXOffset, tileCoordY + mapYOffset

    def pauseMovement(self):
        self.robot_cancel_pub.publish(GoalID())

    def resumeMovement(self):
        self.moveToPosition(self.goal)


def main():
    rospy.init_node('movement', anonymous=True)
    Movement()

    rospy.spin()


if __name__ == '__main__':
    main()
