#!/usr/bin/env python
import math
import threading
import time

import rospy
from actionlib_msgs.msg import GoalID, GoalStatusArray
from geometry_msgs.msg import Pose, PoseStamped, PoseWithCovarianceStamped, Twist, Quaternion
from std_msgs.msg import Int8
from tf import transformations as tf

# Parameters
mapXOffset = 16
mapYOffset = 16
slowRotateSpeed = 0.5
slowRotateTime = 21.5  # In seconds
statusInterval = 1  # In seconds

# TODO: make sure the status is not finished from the last goal, even though you wanted to move


class PausableTimer:

    def __init__(self, interval, callback):
        self.interval = interval
        self.callback = callback
        self.timer = threading.Timer(interval, callback)
        self.t0 = time.time()
        self.t1 = None

    def start(self):
        self.timer.start()

    def cancel(self):
        self.timer.cancel()

    def pause(self):
        self.timer.cancel()
        self.t1 = time.time()

    def resume(self):
        self.interval = self.interval - self.t1 + self.t0
        self.t0 = time.time()
        self.timer = threading.Timer(self.interval, self.callback)
        self.timer.start()


class Movement:

    DEFAULT = -1
    FINISHED_MOVING = 0
    FINISHED_ROTATING = 1
    MOVING = 2
    ROTATING = 3
    INTERRUPTED_MOVING = 4
    INTERRUPTED_ROTATING = 5
    BYPASSING_NAVSTACK = 6
    FINISHED_BYPASSING = 7

    def __init__(self):
        # Init subscribers
        self.command_sub = rospy.Subscriber("/movement/command", Int8, self.commandCallback)
        self.next_goal_sub = rospy.Subscriber("/movement/pose", Pose, self.moveToPosition)
        self.goal_status_sub = rospy.Subscriber("move_base/status", GoalStatusArray, self.statusCallback)

        # Init publishers
        self.result_pub = rospy.Publisher("/movement/status", Int8, queue_size=10)
        self.robot_goal_pub = rospy.Publisher("/move_base_simple/goal", PoseStamped, queue_size=10)
        self.robot_cmd_vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        self.robot_cancel_pub = rospy.Publisher("/move_base/cancel", GoalID, queue_size=10)

        # Init variables
        self.status = self.DEFAULT
        self.timer = None
        self.goal = None

        # Start publishing the status to the state machine
        self.publishStatus()

    def statusCallback(self, data):
        # data = GoalStatusArray()
        if len(data.status_list) > 0:
            status = data.status_list[len(data.status_list) - 1]
            # status = GoalStatus()

            if status.status == 3:  # If move is finished

                if self.status == self.ROTATING:
                    self.status = self.FINISHED_ROTATING
                    print("Finished rotating")

                elif self.status == self.MOVING:
                    self.status = self.FINISHED_MOVING
                    print("Finished moving")

                elif self.status == self.BYPASSING_NAVSTACK:
                    self.status = self.FINISHED_BYPASSING

    def publishStatus(self):
        if self.status == 5:  # The state machine only has 4, not 4 & 5
            self.result_pub.publish(4)
        elif self.status == 6 or self.status == 7:
            self.result_pub.publish(self.MOVING)  # The state machine does not have 6
        else:
            self.result_pub.publish(self.status)
        threading.Timer(statusInterval, self.publishStatus).start()

    def commandCallback(self, data):
        if data.data == 1:
            self.rotateSlowly()
        elif data.data == 2:
            self.interrupt()
        elif data.data == 3:
            self.resume()

    def moveToPosition(self, data):

        if self.status == self.MOVING or self.status == self.ROTATING:
            print("Already have command (status=" + str(self.status) + ") but got move command")

        # Save the goal in case there is an interrupt
        self.goal = data

        print("Got move command. Will rotate and then move")

        current_pose = rospy.wait_for_message("/amcl_pose", PoseWithCovarianceStamped)
        # current_pose = PoseWithCovarianceStamped()
        # data = Pose()

        # Calculate angle of the line between the current pose and the goal
        deltaX = data.position.x - current_pose.pose.pose.position.x
        deltaY = data.position.y - current_pose.pose.pose.position.y
        angle = tf.quaternion_from_euler(0, 0, math.atan2(deltaY, deltaX))

        # Send rotation
        robot_goal = PoseStamped()
        robot_goal.pose.position = current_pose.pose.pose.position
        robot_goal.pose.orientation = Quaternion(x=angle[0], y=angle[1], z=angle[2], w=angle[3])
        robot_goal.header.frame_id = "map"
        self.robot_goal_pub.publish(robot_goal)  # TODO: do we need some sleep() ?
        self.status = self.BYPASSING_NAVSTACK

        while self.status == self.BYPASSING_NAVSTACK:
            rospy.sleep(0.2)

        print("I finished rotating and will move")

        if self.status == self.INTERRUPTED_MOVING:
            print "Actually, I got interrupted and will not move"
            return

        # Send actual goal
        robot_goal = PoseStamped(pose=data)
        robot_goal.header.frame_id = "map"
        self.robot_goal_pub.publish(robot_goal)
        self.status = self.MOVING

    def rotateSlowly(self):
        waitTime = self.getRotateTime()
        self.timer = PausableTimer(waitTime, self.timerCallback)
        self.timer.start()

        self.publishRotation()

    def publishRotation(self):
        print("Rotating")
        self.status = self.ROTATING

        rotate_command = Twist()
        rotate_command.angular.z = slowRotateSpeed

        rate = rospy.Rate(10)  # 10hz

        while self.status == self.ROTATING and not rospy.is_shutdown():
            self.robot_cmd_vel_pub.publish(rotate_command)
            rate.sleep()

        # Stop rotating
        self.robot_cmd_vel_pub.publish(Twist())

    def timerCallback(self):
        self.status = 1
        print "Finished rotating"

    def interrupt(self):
        if self.status == self.MOVING or self.status == self.BYPASSING_NAVSTACK:
            self.status = self.INTERRUPTED_MOVING
            self.pauseMovement()
            print "Interrupted movement"

        elif self.status == self.ROTATING:
            self.status = self.INTERRUPTED_ROTATING
            self.pauseSlowRotation()
            print "Interrupted rotating"

        else:
            print "Got interrupt command but my status was " + str(self.status)

    def resume(self):
        if self.status == self.INTERRUPTED_MOVING:
            print "Resuming movement"
            self.resumeMovement()

        elif self.status == self.INTERRUPTED_ROTATING:
            print "Resuming rotation"
            self.resumeSlowRotation()

        else:
            print "Got resume command but my status was " + str(self.status)

    @staticmethod
    def getRotateTime():
        return slowRotateTime

    def pauseSlowRotation(self):
        self.timer.pause()

    def resumeSlowRotation(self):
        self.timer.resume()
        self.publishRotation()

    @staticmethod
    def convertToMapCoord(tileCoordX, tileCoordY):
        return tileCoordX + mapXOffset, tileCoordY + mapYOffset

    def pauseMovement(self):
        self.robot_cancel_pub.publish(GoalID())  # TODO: check how to get the right ID

    def resumeMovement(self):
        self.moveToPosition(self.goal)


def main():
    rospy.init_node('movement', anonymous=True)
    Movement()

    rospy.spin()


if __name__ == '__main__':
    main()
