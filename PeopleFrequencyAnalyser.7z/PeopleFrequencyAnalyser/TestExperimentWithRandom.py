import CreateTiles as CT
import FoundPerson as FP
import random
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import numpy as np

mapTile = CT.TileMap(9, 9, 3, 3,True)
foundPerson = FP.PersonGridMap(mapTile, True)
counter = 0
gridArray = [[0 for x in range(3)] for y in range(3)]

gridArray[0][0] = 9
gridArray[0][1] = 3
gridArray[0][2] = 9


gridArray[1][0] = 6
gridArray[1][1] = 7
gridArray[1][2] = 6


gridArray[2][0] = 9
gridArray[2][1] = 3
gridArray[2][2] = 9

for i in range(0,20):
    personX = random.randint(0,9)
    personY = random.randint(0,9)
    personTile = foundPerson.tileOfPersonFound((personX,personY))
    locationTile = mapTile.mapPositionOfTile(personTile)
    mapTile.putReachableLocation(locationTile[0], locationTile[1], (personX,personY))
    
    if(gridArray[locationTile[0]][locationTile[1]] > random.randint(0,11)):
        foundPerson.addPersonOnGrid(personTile)
        counter += 1
    else:
        foundPerson.noPersonFoundAtLocation(personTile)

    foundPerson.fromNormalisedToProbabilityGrid()

print counter