from __future__ import division
import numpy as np
import os

class Tile:
    def __init__(self,x0,y0,x1,y1):
        self.x0 = x0
        self.x1 = x1
        self.y0 = y0
        self.y1 = y1
        self.isReachable = True

    # Gets the middle point of the tile
    def getMiddle(self):
        x_middle = (self.x0 + self.x1)//2
        y_middle = (self.y0 + self.y1)//2
        return (x_middle,y_middle)

    #It is going to be called when re-route happens or when an obstacle is found
    def objectIsOnTile(self):
        self.isReachable = False

    def __str__(self):
        response="Tile, middle: "+str(self.getMiddle())
        return response



class TileMap:
    def __init__(self,width,height,numTilesWidth,numTilesHeight, hasData):
        self.width = width
        self.height = height
        self.numTilesHeight = numTilesHeight
        self.numTilesWidth = numTilesWidth
        self.map = self.splitIntoTilesfromMap() #This is a list of all the tiles in the map
        self.mapGrid = self.getTilesArray2D()
        self.mapMiddleTile = self.getMiddlePointOfTiles() #This is the 2D Array that stores the middle points of every tile
        self.reachableLocations = [[None for x in range(self.numTilesWidth)] for y in range(self.numTilesHeight)]
        if hasData:
            self.readReachable()
    '''
    This function gets the size of a tile based on the parameters of the map and how many tiles
    we want per width or per height. After that it splits the map based on this size and
    gives back an array for all the tiles
    '''

    def readReachable(self):
        file = open("reachableX.txt", "r")
        file2 = open("reachableY.txt", "r")

        j = 0
        for line in file:
            line2 = file2.readline()
            first = np.fromstring(line, sep=" ")
            second = np.fromstring(line2, sep=" ")
            for i in range(0,len(first)):
                self.reachableLocations[j][i] = (first[i], second[i])
            j += 1
        file.close()
        file2.close()
        print self.reachableLocations

    def saveReachable(self):
        path = "reachableX.txt"
        path2 = "reachableY.txt"
        try:
            os.remove(path)
            os.remove(path2)
            print "Existing file deleted.\n"
        except OSError:
            print "File not found, continuing...\n"
        file = open(path, "w")
        file2 = open(path2, "w")
        for values in np.array(self.reachableLocations):
            # i += 1
            for value in values:
                if value!=None:
                    file.write(str(value[0]) + ' ')
                    file2.write(str(value[1]) + ' ')
                else:
                    file.write(str(-1) + ' ')
                    file2.write(str(-1) + ' ')
            file.write("\n")
            file2.write("\n")
        file.close()
        file2.close()

    def splitIntoTilesfromMap(self):
        tileArray = []
        maxWidthperTile = self.getMaximumWidthTile()
        maxHeightperTile = self.getMaximumHeightTile()
        for x in range (0,self.width,maxWidthperTile):
            for y in range (0,self.height,maxHeightperTile):
                    tileArray.append(Tile(x,y,x+maxWidthperTile,y+maxHeightperTile))
        return tileArray

    def getTilesArray2D(self):
        maxWidthperTile = self.getMaximumWidthTile()
        maxHeightperTile = self.getMaximumHeightTile()
        itx = 0
        ity = 0
        tileArray = [[0 for x in range(self.numTilesWidth)] for y in range(self.numTilesHeight)]
        for i in range (0,self.width,maxWidthperTile):
            for j in range (0,self.height,maxHeightperTile):
                    tileArray[itx][ity] = (Tile(i,j,i+maxWidthperTile,j+maxHeightperTile))
                    ity += 1
            itx +=1
            ity = 0
        return tileArray
    '''
    This function stores the middle points of each coresponding tile in a 2D array. The 2D Array
    is an actual representation of the grid map, such that it makes it easier to see the neighbour tiles
    and which tiles are reachable when doing A star search
    '''
    def getMiddlePointOfTiles(self):
        maxWidthperTile = self.getMaximumWidthTile()
        maxHeightperTile = self.getMaximumHeightTile()
        itx = 0
        ity = 0
        tileMiddleArray = [[0 for x in range(self.numTilesWidth)] for y in range(self.numTilesHeight)]
        for i in range (0,self.width,maxWidthperTile):
            for j in range (0,self.height,maxHeightperTile):
                    tileMiddleArray[itx][ity] = (Tile(i,j,i+maxWidthperTile,j+maxHeightperTile)).getMiddle()
                    ity += 1
            itx +=1
            ity = 0
        return tileMiddleArray

    '''
    This function takes a point(location) and provides the coresponding tile in the map
    '''
    def localisePointOnTile(self,x, y):
        for it in self.map:
                if(it.x0 <= x and it.y0 <=y and it.x1 >= x and it.y1 >=y):
                    print(it)
                    return it

    '''
    This function finds the corresponding location of a tile in the tile map
    '''
    def mapPositionOfTile(self,tile):
        if(tile.x0%self.getMaximumWidthTile() == 0):
            posX = tile.x0//self.getMaximumWidthTile()
        else:
            posX = tile.x0//self.getMaximumWidthTile()+1

        if(tile.y0%self.getMaximumHeightTile() == 0):
            posY = tile.y0//self.getMaximumHeightTile()
        else:
            posY = tile.y0//self.getMaximumHeightTile()+1
        return (posX,posY)

    def getMaximumWidthTile(self):
        return 	self.width//self.numTilesWidth

    def getMaximumHeightTile(self):
        return	self.height//self.numTilesHeight

    def putReachableLocation(self, x, y, location):
        self.reachableLocations[x][y] = location
        self.saveReachable()

    def getReachableLocation(self, x, y):
        return self.reachableLocations[x][y]




