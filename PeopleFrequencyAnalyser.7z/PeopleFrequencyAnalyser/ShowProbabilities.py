#! /usr/bin/env python

import rospy
from std_msgs.msg import Float32MultiArray
import matplotlib.pyplot as plt
import matplotlib.colors as colors
#sudo pip install matplotlib   -> to install

import numpy as np

class ShowProbabilities:
    def __init__(self):
        rospy.init_node('showProbabilities', anonymous=True)
        rospy.Subscriber("probabilities", Float32MultiArray, self.callback)
        rospy.spin()

    def callback(self,msg):
        image_rows = (np.split(np.array(msg.data), 8))

        self.show(image_rows)
        #print "showing ",msg

    def show(self, grid):
        plt.clf()
        plt.title('Grid')
        a = np.array(grid)
        plt.imshow(a, cmap=plt.get_cmap('Reds'), interpolation='nearest', vmax=0.1)
        plt.show()

if __name__ == "__main__":
    ShowProbabilities()