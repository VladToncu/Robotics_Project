import CreateTiles as CT
import FoundPerson as FP
import random

counter = 0
mapTile = CT.TileMap(9, 9, 3, 3,True)
foundPerson = FP.PersonGridMap(mapTile, True)

gridArray = [[0 for x in range(3)] for y in range(3)]

gridArray[0][0] = 9
gridArray[0][1] = 3
gridArray[0][2] = 9


gridArray[1][0] = 6
gridArray[1][1] = 7
gridArray[1][2] = 6


gridArray[2][0] = 9
gridArray[2][1] = 3
gridArray[2][2] = 9

for i in range(0,20):
    robotPosition = foundPerson.getMaximumProbability()
    robotTile = mapTile.localisePointOnTile(robotPosition[0], robotPosition[1])
    locationTile = mapTile.mapPositionOfTile(robotTile)
    
    if(gridArray[locationTile[0]][locationTile[1]] > random.randint(0,11)):
        foundPerson.addPersonOnGrid(personTile)
        counter += 1
    else:
        foundPerson.noPersonFoundAtLocation(robotTile)
    foundPerson.fromNormalisedToProbabilityGrid()

print counter