import CreateTiles as CT
import FoundPerson as FP
import random
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import numpy as np

mapTile = CT.TileMap(32,32,8,8,True)
foundPerson = FP.PersonGridMap(mapTile, False)

for x in range (0,200):

	personX = random.randint(0,32)
	personY = random.randint(0,32)
	personTile = foundPerson.tileOfPersonFound((personX,personY))
	locationTile = mapTile.mapPositionOfTile(personTile)
	mapTile.putReachableLocation(locationTile[0], locationTile[1], (personX,personY))

	print(personTile)

	foundPerson.addPersonOnGrid(personTile)

	print("Start changing the probability map")
	foundPerson.fromNormalisedToProbabilityGrid()
	#foundPerson.printGrids()

for i in range(0,200):
    robotPosition = foundPerson.getMaximumProbability()
    robotTile = mapTile.localisePointOnTile(robotPosition[0], robotPosition[1])
    foundPerson.noPersonFoundAtLocation(robotTile)
while True:
    print("Start moving")
    plt.clf()
    plt.title('Grid')
    a = np.array(foundPerson.probabilityGrid)
    plt.imshow(a, cmap=plt.get_cmap('Reds'), interpolation='nearest', vmax = 0.1)
    plt.show()

    robotPosition = foundPerson.getMaximumProbability()
    robotTile = mapTile.localisePointOnTile(robotPosition[0], robotPosition[1])

    foundPerson.noPersonFoundAtLocation(robotTile)

