from __future__ import division
import CreateTiles
import numpy as np
import os

import rospy
from std_msgs.msg import Float32MultiArray

class PersonGridMap:
    def __init__(self,Tilemap, loadedData):
        #rospy.init_node('personGridMap', anonymous=True)

        #self.pub = rospy.Publisher('probabilities', Float32MultiArray, queue_size=10)
        self.Tilemap = Tilemap
        self.personGrid = self.initialiseGrid()
        self.probabilityGrid = self.initialiseGrid()
        self.numberOfPeople = 0
        self.numberOfPeopleOnEqual = 0
        self.counterNormalised = 0
        if(loadedData == True):
            self.takePersonGridFromText()
            self.getNumberOfPeople()
            self.fromNormalisedToProbabilityGrid()

    def takePersonGridFromText(self):
        file = open("probs.txt", "r")
        j = 0
        for line in file:
            first = np.fromstring(line, sep=" ")
            for i in range(0,len(first)):
                self.personGrid[j][i] = int(first[i])
            j += 1
        print self.personGrid
        file.close()

    def getProbability(self, tile):
        tilePositionOnMap = self.Tilemap.mapPositionOfTile(personTile)
        print(tilePositionOnMap)
        tilePositionX = tilePositionOnMap[0]
        tilePositionY = tilePositionOnMap[1]
        return probabilityGrid[tilePositionX][tilePositionY]

    def savePersonGrid(self):
        path = "probs.txt"
        try:
            os.remove(path)
            print "Existing file deleted.\n"
        except OSError:
            print "File not found, continuing...\n"
        file = open(path, "w")
        for values in np.array(self.personGrid):
            # i += 1
            for value in values:
                file.write(str(int(value)) + ' ')
                # print int(value)
            file.write("\n")
        file.close()

    def initialiseGrid(self):
        maxWidthperTile = self.Tilemap.getMaximumWidthTile()
        maxHeightperTile = self.Tilemap.getMaximumHeightTile()
        itx = 0
        ity = 0
        gridArray = [[0 for x in range(self.Tilemap.numTilesWidth)] for y in range(self.Tilemap.numTilesHeight)]
        for i in range (0,self.Tilemap.width,maxWidthperTile):
            for j in range (0,self.Tilemap.height,maxHeightperTile):
                gridArray[itx][ity] = 0
                ity += 1
            itx +=1
            ity = 0
        return gridArray

    def printGrid(self,grid):
        maxWidthperTile = self.Tilemap.getMaximumWidthTile()
        maxHeightperTile = self.Tilemap.getMaximumHeightTile()
        itx = self.Tilemap.numTilesWidth - 1
        ity = 0
        for i in range (0,self.Tilemap.width,maxWidthperTile):
            for j in range (0,self.Tilemap.height,maxHeightperTile):
                #print (grid[ity][itx], end=" ")
                ity += 1
            #print("\n")
            itx -=1
            ity = 0
    def printPeopleGrid(self):
        self.printGrid(self.personGrid)

    def printProbabilityGrid(self):
        self.printGrid(self.probabilityGrid)

    def printGrids(self):

        print("This is the people grid")
        self.printPeopleGrid()

        print("This is the probability grid")
        self.printProbabilityGrid()

    def tileOfPersonFound(self,currentPositionRobot):
        return self.Tilemap.localisePointOnTile(currentPositionRobot[0], currentPositionRobot[1])

    def addPersonOnGrid(self,personTile):
        tilePositionOnMap = self.Tilemap.mapPositionOfTile(personTile)
        print(tilePositionOnMap)
        tilePositionX = tilePositionOnMap[0]
        tilePositionY = tilePositionOnMap[1]

        self.personGrid[tilePositionX][tilePositionY] += 1
        self.numberOfPeople += 1
        '''
                if self.counterNormalised < 3:
                    self.counterNormalised += 1

                else:
                    self.fromNormalisedToProbabilityGrid()
                    self.counterNormalised = 0
        '''
        self.savePersonGrid()
        self.fromNormalisedToProbabilityGrid()

    def noPersonFoundAtLocation(self, currentTile):
        tilePositionOnMap = self.Tilemap.mapPositionOfTile(currentTile)
        print(tilePositionOnMap)
        tilePositionX = tilePositionOnMap[0]
        tilePositionY = tilePositionOnMap[1]
        q = 0.9 # Likelihood of finding a person if it was in this location
        p = self.probabilityGrid[tilePositionX][tilePositionY]  # Probability of someone baing in this location
        for i in range(0,len(self.probabilityGrid)):
            for j in range(0,len(self.probabilityGrid[i])):
                r = self.probabilityGrid[i][j]                  # Probability of someone being at (i,j) location
                if i==tilePositionX and j==tilePositionY:
                    self.probabilityGrid[i][j] = p*(1-q)/(1-p*q) # Decrease the probability of current tile
                else:
                    self.probabilityGrid[i][j] = r/(1-p*q)      # Increase the probability of other titles
    def createNormalisedGrid(self,grid,sumOfGrid):
        maxWidthperTile = self.Tilemap.getMaximumWidthTile()
        maxHeightperTile = self.Tilemap.getMaximumHeightTile()
        itx = 0
        ity = 0
        normalisedGrid = [[0 for x in range(self.Tilemap.numTilesWidth)] for y in range(self.Tilemap.numTilesHeight)]
        for i in range (0,self.Tilemap.width,maxWidthperTile):
            for j in range (0,self.Tilemap.height,maxHeightperTile):
                normalisedGrid[itx][ity] = grid[itx][ity]/sumOfGrid
                ity += 1
            itx +=1
            ity = 0
        return normalisedGrid

    def createNormalisedPeopleGrid(self):
        return self.createNormalisedGrid(self.personGrid, self.numberOfPeople)


    def fromNormalisedToProbabilityGrid(self):
        normalisedGrid = self.createNormalisedPeopleGrid()

        maxWidthperTile = self.Tilemap.getMaximumWidthTile()
        maxHeightperTile = self.Tilemap.getMaximumHeightTile()
        itx = 0
        ity = 0
        sumProbabilities = 0
        transformGrid = [[0 for x in range(self.Tilemap.numTilesWidth)] for y in range(self.Tilemap.numTilesHeight)]
        for i in range (0,self.Tilemap.width,maxWidthperTile):
            for j in range (0,self.Tilemap.height,maxHeightperTile):
                transformGrid[itx][ity] = normalisedGrid[itx][ity]+self.probabilityGrid[itx][ity]
                sumProbabilities += transformGrid[itx][ity]
                ity += 1
            itx +=1
            ity = 0

        self.probabilityGrid = self.createNormalisedGrid(transformGrid, sumProbabilities)
        #msg = Float32MultiArray()
        #msg.data = np.array(self.probabilityGrid).flatten()
        #rospy.sleep(0.001)  # for some reason it can't publish to a topic as quickly as this is running without the timeout
        #self.pub.publish(msg)

        #print "publishing msg to view tile map: ",msg

    # This is the function that needs to be called before the traveling is being done. THis will give the tile where the robot should go. Then the robot will
    # need to take the middle of that tile (there is a function for that) and go there.
    def getMaximumProbability(self):
        maxWidthperTile = self.Tilemap.getMaximumWidthTile()
        maxHeightperTile = self.Tilemap.getMaximumHeightTile()
        itx = 0
        ity = 0
        maximum = 0.0
        maxTile = self.Tilemap.mapGrid[0][0]
        maxLoc = (0,0)
        for i in range (0,self.Tilemap.width,maxWidthperTile):
            for j in range (0,self.Tilemap.height,maxHeightperTile):
                if(self.probabilityGrid[itx][ity] > maximum):
                    maximum = self.probabilityGrid[itx][ity]
                    maxTile=self.Tilemap.mapGrid[itx][ity]
                    maxLoc = (itx, ity)
                ity += 1
            itx +=1
            ity = 0
        return self.Tilemap.getReachableLocation(maxLoc[0], maxLoc[1])


    def isProbabilityMapEqual(self):
        maxWidthperTile = self.Tilemap.getMaximumWidthTile()
        maxHeightperTile = self.Tilemap.getMaximumHeightTile()
        itx = 0
        ity = 0
        previous = self.probabilityGrid[itx][ity]
        for i in range (0,self.Tilemap.width,maxWidthperTile):
            for j in range (0,self.Tilemap.height,maxHeightperTile):
                if(self.probabilityGrid[itx][ity] != previous):
                    return False
                ity += 1
            itx +=1
            ity = 0

        self.numberOfPeopleOnEqual = self.numberOfPeople
        self.counterNormalised = 0
        return True

    def stopGoingOnPattern(self):
        if(self.numberOfPeople >= self.numberOfPeopleOnEqual + 5):
            return True
        return False

    def getNumberOfPeople(self):
        maxWidthperTile = self.Tilemap.getMaximumWidthTile()
        maxHeightperTile = self.Tilemap.getMaximumHeightTile()
        itx = 0
        ity = 0
        for i in range (0,self.Tilemap.width,maxWidthperTile):
            for j in range (0,self.Tilemap.height,maxHeightperTile):
                self.numberOfPeople += self.personGrid[itx][ity]
                self.numberOfPeopleOnEqual += self.personGrid[itx][ity]
                ity += 1
            itx +=1
            ity = 0









