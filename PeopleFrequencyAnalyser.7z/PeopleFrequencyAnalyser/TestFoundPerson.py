import CreateTiles as CT
import FoundPerson as FP

mapTile = CT.TileMap(12,12,3,3)
foundPerson = FP.PersonGridMap(mapTile)

foundPerson.printGrids()

print("The first person was found")
personTile = foundPerson.tileOfPersonFound((1,1))

foundPerson.addPersonOnGrid(personTile)

foundPerson.printGrids()

print("Start changing the probability map")
foundPerson.fromNormalisedToProbabilityGrid()

foundPerson.printGrids()


print("The second person was found")
personTile = foundPerson.tileOfPersonFound((8,6))

foundPerson.addPersonOnGrid(personTile)
foundPerson.printGrids()

print("Start changing the probability map")
foundPerson.fromNormalisedToProbabilityGrid()

foundPerson.printGrids()


print("The third person was found")
personTile = foundPerson.tileOfPersonFound((2,1))

foundPerson.addPersonOnGrid(personTile)
foundPerson.printGrids()

print("Start changing the probability map")
foundPerson.fromNormalisedToProbabilityGrid()

foundPerson.printGrids()


print("The fourth person was found")
personTile = foundPerson.tileOfPersonFound((8,6))

foundPerson.addPersonOnGrid(personTile)
foundPerson.printGrids()

print("Start changing the probability map")
foundPerson.fromNormalisedToProbabilityGrid()

foundPerson.printGrids()


print("The fifth person was found")
personTile = foundPerson.tileOfPersonFound((2,6))

foundPerson.addPersonOnGrid(personTile)
foundPerson.printGrids()

print("Start changing the probability map")
foundPerson.fromNormalisedToProbabilityGrid()

foundPerson.printGrids()