#!/usr/bin/env python
from __future__ import print_function
import roslib

roslib.load_manifest('project')
import sys
import rospy
import cv2
import time
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

import tty, termios

imageDimen = (200, 200)
CROP_RATIO = 0.1  # How much to crop on the sides
MINIMUM_FACE_DIMENSION = 100

video_capture = cv2.VideoCapture(0)
cascPath = "/home/alex/opencv/data/haarcascades/haarcascade_frontalface_alt.xml"
faceCascade = cv2.CascadeClassifier(cascPath)


class image_converter:
    def __init__(self):

        # self.image_pub_face = rospy.Publisher("face", Image, queue_size=10)
        # self.image_pub_web = rospy.Publisher("webcamImage", Image, queue_size=10)
        # self.image_sub_web = rospy.Subscriber("webcamImage", Image, self.callback)
        # self.image_sub_kinect = rospy.Subscriber("/camera/rgb/image_color", Image, self.callback)

        self.bridge = CvBridge()

    def callback(self, data):
        self.processData(data)

    def processData(self, data):
        try:
            frame = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        faces = faceCascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30)
        )

        # Crop
        if len(faces) == 0:
            print("No faces detected")
            return


        maxH = 0
        maxI = 0
        for i in (0, len(faces)-1):
            print(faces[i][3])
            if faces[i][3]>maxH:
                maxH = faces[i][3]
                maxI = i

        (x, y, w, h) = faces[maxI]


        if (h < MINIMUM_FACE_DIMENSION):
            print("The face is too small")
            return


        croppedImage = frame[y:y + h, x:x + w]

        # Crop again to remove background on the sides
        cropAmount = w * CROP_RATIO
        croppedImage = croppedImage[0:h, cropAmount:w - cropAmount]

        #croppedImage = cv2.resize(croppedImage, imageDimen)

        path = "/home/alex/Pictures/faces" + str(time.time()) + ".png"
        cv2.imwrite(path, croppedImage)

        cv2.imshow("Image window", croppedImage)
        cv2.waitKey(3)

        print("Got picture")


def getch():
    import termios
    import sys, tty
    def _getch():
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

    return _getch()


def main(args):
    ic = image_converter()
    rospy.init_node('image_converter', anonymous=True)

    # while True:
    #   if cv2.waitKey(1) & 0xFF == ord('q'):
    #       break

    while True:
        char = getch()
        print(char)

        if (char == "q"):
            break
        if (char == "a" or char == " "):
            data = rospy.wait_for_message("/camera/rgb/image_color", Image)
            ic.processData(data)

    # When everything is done, release the capture
    video_capture.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main(sys.argv)
