#!/usr/bin/env python
import rospy
from move_base_msgs.msg import MoveBaseGoal, MoveBaseAction
import actionlib

rospy.init_node("mover")

ac = actionlib.SimpleActionClient('test', MoveBaseAction)

while not ac.wait_for_server(rospy.Duration(5.0)):
    rospy.loginfo("Waiting for the move_base action server to come up")

# Init

goal = MoveBaseGoal()
goal.target_pose.header.frame_id = "base_link"
goal.target_pose.header.stamp = rospy.Time.now()

# Set actual goal
goal.target_pose.pose.position.x = 1.0
goal.target_pose.pose.position.y = 0.0
goal.target_pose.pose.orientation.w = 1.0

rospy.loginfo("Sending goal")

ac.send_goal(goal)

ac.wait_for_result()

rospy.loginfo("Done")


