import cv2
video_capture = cv2.VideoCapture(0)
video_capture.release()