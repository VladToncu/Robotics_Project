#!/usr/bin/env python

import sys
import cv2
import time
import os

import roslib
import rospy
from sensor_msgs.msg import Image

from cv_bridge import CvBridge, CvBridgeError

import signal
import sys


roslib.load_manifest('security_guard')


MINIMUM_FACE_DIMENSION = 100
OUTPUT_FACE_DIMENSIONS = (80, 100) # The dimensions of the output images
CROP_RATIO = 0.1 # How much to crop on the sides

useWebcam = False

TIMER_TRESHOLD = 0.5
DELAY_FACE_RECOGNITION = 1

faceCascadePath = "/haarcascade_frontalface_alt.xml"
eyeCascadePath = "/haarcascade_eye.xml"


class faceDetection:

    timer = None

    def __init__(self):
        self.timer = time.time()
        self.delayTimer = None

        # Init publishers and subscribers
        self.image_sub_kinect = rospy.Subscriber("/camera/rgb/image_color", Image, self.callback)
        self.image_pub_face = rospy.Publisher("face", Image, queue_size=10)
        if useWebcam:
            self.image_pub_web = rospy.Publisher("webcamImage", Image, queue_size=10)
            self.image_sub_web = rospy.Subscriber("webcamImage", Image, self.callback)
            self.video_capture = cv2.VideoCapture(0)

        # Init face detector
        filePath = os.path.dirname(os.path.abspath(__file__))
        self.faceCascade = cv2.CascadeClassifier(filePath + faceCascadePath)
        self.eyeCascade = cv2.CascadeClassifier(filePath + eyeCascadePath)

        # Init CV Bridge
        self.bridge = CvBridge()
        self.counter = 0

    def callback(self, data):

        if time.time() - self.timer < TIMER_TRESHOLD:
            return

        self.timer = time.time()

        self.counter = 0
        try:
            frame = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        faces = self.faceCascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(50, 50)
        )

        # Draw a rectangle around the faces
        # for (x, y, w, h) in faces:
        #    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

        if len(faces) == 0:
            cv2.imshow("Image window", frame)
            cv2.waitKey(3)
            # print("No faces detected")
            return

        # Check again with noise reduction
        # gaussian = cv2.GaussianBlur(gray, (7, 7), 0)
        # faces = self.faceCascade.detectMultiScale(
        #     gaussian,
        #     scaleFactor=1.1,
        #     minNeighbors=5,
        #     minSize=(50, 50)
        # )
        #
        # if len(faces) == 0:
        #     cv2.imshow("Image window", frame)
        #     cv2.waitKey(3)
        #     print("Face detected in raw image, but not in the smooth image")
        #     return

        # Got ok face. Delay for a while
        if self.delayTimer == None: # Not set
            self.delayTimer = time.time()
            return
        elif time.time() - self.delayTimer < DELAY_FACE_RECOGNITION:
            return
        self.delayTimer = None

        maxH = 0
        maxI = 0
        for i in (0, len(faces) - 1):
            # print(faces[i][3])
            if faces[i][3] > maxH:
                maxH = faces[i][3]
                maxI = i

        (x, y, w, h) = faces[maxI]


        if(h<MINIMUM_FACE_DIMENSION):
            print h
            print("The face is too small")
            tooSmallError = Image()
            tooSmallError.header.seq = -1
            self.image_pub_face.publish(tooSmallError)
            cv2.imshow("Image window", frame)
            cv2.waitKey(3)
            return

        # Crop the face square
        croppedImage = frame[y:y + h, x:x + w]

        # Crop again to remove background on the sides
        cropAmount = w * CROP_RATIO
        croppedImage = croppedImage[0:h, cropAmount:w-cropAmount]

        # # Detect eyes
        # gray = cv2.cvtColor(croppedImage, cv2.COLOR_BGR2GRAY)
        # eyes = self.eyeCascade.detectMultiScale(
        #     gray,
        #     scaleFactor=1.1,
        #     minNeighbors=15,
        #     minSize=(30, 30)
        # )
        # for (ex, ey, ew, eh) in eyes:
        #     cv2.rectangle(croppedImage, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)

        # Resize
        resizedImage = cv2.resize(croppedImage, OUTPUT_FACE_DIMENSIONS)

        try:
            self.image_pub_face.publish(self.bridge.cv2_to_imgmsg(resizedImage, "bgr8"))
        except CvBridgeError as e:
            print(e)


        path = "/home/alex/Pictures/runtimeFaces/" + str(time.time()) + ".png"
        cv2.imwrite(path, resizedImage)

        cv2.imshow("Image window", resizedImage)
        cv2.waitKey(3)

    def captureWebcamAndSend(self):
        if not self.video_capture.isOpened():
            print('Unable to load camera.')
            time.sleep(5)
            pass

        ret, frame = self.video_capture.read()

        try:
            self.image_pub_web.publish(self.bridge.cv2_to_imgmsg(frame, "bgr8"))
        except CvBridgeError as e:
            print(e)

    def releaseWebcam(self):
        self.video_capture.release()
        cv2.destroyAllWindows()


ic = faceDetection()

def signal_handler(signal, frame):
    global ic
    ic.releaseWebcam()
    sys.exit(0)

def main(args):
    global ic
    signal.signal(signal.SIGINT, signal_handler)
    #ic = faceDetection()
    rospy.init_node('face_detection', anonymous=True)

    if useWebcam:
        try:
            while True:
                ic.captureWebcamAndSend()
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except KeyboardInterrupt:
            print("Interrupted")

        # When everything is done, release the capture
        ic.releaseWebcam()
    else:
        rospy.spin()


if __name__ == '__main__':
    main(sys.argv)